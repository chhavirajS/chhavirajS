﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public abstract class Animal : BaseEntity
    {
        public bool CanFly { get; protected set; }

        public Animal(AnimalType animalType)
        {
            this.AnimalType = animalType;
        }

        public virtual string AnimalNoise()
        {
            return "No noise";
        }
    }
}
