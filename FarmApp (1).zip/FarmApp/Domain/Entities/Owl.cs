﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Owl : Bird
    {
        public Owl() :base(AnimalType.Owl)
        {

        }

        public override string AnimalNoise()
        {
            return "Hoot";
        }
    }
}
