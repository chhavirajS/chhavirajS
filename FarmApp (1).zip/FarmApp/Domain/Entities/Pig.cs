﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Pig : Mammal
    {
        public Pig() :base(AnimalType.Pig)
        {
            NumberOfLegs = 4;
        }

        public override string AnimalNoise()
        {
            return "Oink";
        }
    }
}
