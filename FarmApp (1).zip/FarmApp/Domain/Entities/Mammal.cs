﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Mammal : Animal
    {
        public Mammal(AnimalType animalType) : base(animalType)
        {
        }

        public int NumberOfLegs { get; protected set; }
    }
}
