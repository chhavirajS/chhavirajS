﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
    public class Cow : Mammal
    {
        public Cow() : base(AnimalType.Cow)
        {
            NumberOfLegs = 4;
        }

        public override string AnimalNoise()
        {
            return "Moo";
        }
    }
}
