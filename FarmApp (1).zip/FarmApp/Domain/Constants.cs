﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public enum AnimalType
    {
        None = 0,
        Chicken,
        Cow,
        Pig,
        Owl
    }
}
