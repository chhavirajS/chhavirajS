﻿using Domain.Entities;

namespace FarmApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var driver = new Driver();
            driver.StartRunning();         
        }
    }
}